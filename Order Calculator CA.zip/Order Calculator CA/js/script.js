
function validate() {
  //access the value inside of the text box with id="staffID";
 var staffNumber= document.getElementById(`staffID`).value;

 //request a password strong password with numbers, letters(lower and uppercase) and special character;
 var rgx=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[$*&@#])[0-9a-zA-Z$*&@#]{8,}$/g;
 
 //if the staff number matches with a strong password they will be allowed to navegate;
 if (rgx.test(staffNumber)){
   document.getElementById(`inValid`).style.visibility = `hidden`;
   document.getElementById(`Valid`).style.visibility = `visible`;
   document.getElementById(`output`).innerHTML=output;
  }
  
  else{
    document.getElementById(`inValid`).style.visibility = `visible`;
    document.getElementById(`Valid`).style.visibility = `hidden`;
    
  }
}
document.getElementById(`getUsers`).addEventListener(`click`, getRandom)


function getRandom(){
  fetch('https://randomuser.me/api/?results=5')
  .then((res)=> res.json())
  .then((data)=>{
     let author = data.results;
     let output = '<h2> Customers: </h2>'
     console.log(data);
     author.forEach(function(user){
       output+=`
       <div>
       <img src="${user.picture.medium}" alt="user Picture">    
        <ul>
        <li>${user.email}</li>
        <li>${user.name.first} ${user.name.last}</li>
        </ul>
       </div>
     `;
     });
     document.getElementById(`output`).innerHTML=output;
})
}
