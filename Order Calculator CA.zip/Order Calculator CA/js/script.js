
function validate() {
  //access the value inside of the text box with id="staffID";
 var staffNumber= document.getElementById(`staffID`).value;

 //request a password strong password with numbers, letters(lower and uppercase) and special character;
 var rgx=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[$*&@#])[0-9a-zA-Z$*&@#]{8,}$/g;
 
 //if the staff number matches with a strong password they will be allowed to navegate;
 if (rgx.test(staffNumber)){
   document.getElementById(`inValid`).style.visibility = `hidden`;
   document.getElementById(`Valid`).style.visibility = `visible`;
   document.getElementById(`output`).innerHTML=output;
  }
  
  else{
    document.getElementById(`inValid`).style.visibility = `visible`;
    document.getElementById(`Valid`).style.visibility = `hidden`;
    
  }
}
document.getElementById(`getUsers`).addEventListener(`click`, getRandom)

//FUNCTION TO GET THE RANDOM USER

function getRandom(){
  //The Json will search the random users on the following API
  fetch('https://randomuser.me/api/?results=5')
  .then((res)=> res.json())
  .then((data)=>{
     let author = data.results;
     let output = '<h2> Customers: </h2>'
     console.log(data);
     author.forEach(function(user){
       output+=`
       <div>
           <img src="${user.picture.medium}" alt="user Picture">    
         <ul>
          <li>Name: ${user.name.first} ${user.name.last}</li>
          <li>E-mail: ${user.email}</li>
         </ul>
       </div>
     `;
     });
     document.getElementById(`output`).innerHTML=output;
})
}

//FUNCTION TO GET THE TOTAL PRICE OF THE MENU
var total_items=12;

function CalculateTotalPrice(){

  var total=0;

  for (let i = 1;i <= total_items;i++){
   itemID = document.getElementById("qnt_"+i);
   total = total + parseInt(itemID.value) * parseInt(itemID.getAttribute("data-price"));
  }
  document.getElementById(`ItemsTotal`).innerHTML="$"+total;
}
document.querySelectorAll(`[id^="qnt_"]`).forEach(item =>{
  item.addEventListener(`keyup`, CalculateTotalPrice);
});


