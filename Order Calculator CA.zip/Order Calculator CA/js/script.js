
function validate() {
  //access the value inside of the text box with id="staffID";
 var staffNumber= document.getElementById(`staffID`).value;

 //request a password strong password with numbers, letters(lower and uppercase) and special character;
 var rgx=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[$*&@#])[0-9a-zA-Z$*&@#]{8,}$/g;
 
 //if the staff number matches with a strong password they will be allowed to navegate;
 if (rgx.test(staffNumber)){
   document.getElementById(`inValid`).style.visibility = `hidden`;
   document.getElementById(`Valid`).style.visibility = `visible`;
       }
 else{
   document.getElementById(`inValid`).style.visibility = `visible`;
   document.getElementById(`Valid`).style.visibility = `hidden`;
 }
}

$.ajax({
  url:"https://randomuser.me/",
  dataType:`json`,
  success:function(data){
   alert(data);
  }
});

document.getElementById(`Sumit`).addEventListener(`click`, Sumit);

function Sumit(){
  fetch (`users.json`)
  .then((response)=> response.json())
  .then((data)=>{
    let output =`<h2>Users</h2>`;
    data.forEach(function(user) {
       output+=`
       <ul>
         <li>Name: ${user.name}</li>
         <li>Picture: ${user.picture}</li>
       </ul>`;
    });
    document.getElementById(`output`).innerHTML=output;
  });
};

